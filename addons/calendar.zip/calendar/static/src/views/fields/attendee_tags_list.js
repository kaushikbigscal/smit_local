/** @odoo-module **/

import { TagsList } from "@web/core/tags_list/tags_list";

export class AttendeeTagsList extends TagsList {}

AttendeeTagsList.template = "calendar.AttendeeTagsList";
