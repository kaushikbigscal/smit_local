# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


from . import calendar_provider_config
from . import calendar_popover_delete_wizard
from . import mail_activity_schedule
