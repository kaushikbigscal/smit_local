/** @odoo-module **/
import { registry } from "@web/core/registry";

// Keep track of selected models for filters
let selectedModelIds = [];

/**
 * Get the current timeline model from the page context
 */
function getCurrentTimelineModel() {
    const container = document.getElementById("timeline_container");
    if (container?.dataset.resModel) {
        return container.dataset.resModel;
    }
    console.warn("Falling back to default: customer.timeline");
    return "customer.timeline";
}

/**
 * Filter Timeline by model
 */

async function filterTimelineByModel(modelId, btnEl) {
    try {
        const model = getCurrentTimelineModel();
        const container = document.getElementById('timeline_container');
        if (!container || !container.dataset.resId) return;

        // Update button states
        document.querySelectorAll('.model_filter_btn').forEach(btn =>
            btn.classList.remove('selected_btn'));
        btnEl.classList.add('selected_btn');

        const result = await fetch("/web/dataset/call_kw", {
            method: "POST",
            credentials: "same-origin",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                jsonrpc: "2.0",
                method: "call",
                params: {
                    model: model,
                    method: "filter_timeline_data",
                    args: [modelId],
                    kwargs: {
                        context: { active_id: parseInt(container.dataset.resId) }
                    },
                },
            }),
        });

        const response = await result.json();
        if (response.result && response.result.html) {
            container.innerHTML = response.result.html;
        }
    } catch (error) {
        console.error('Timeline filtering failed:', error);
        // Show error to user
        const container = document.getElementById('timeline_container');
        if (container) {
            container.innerHTML = `
                <div class="alert alert-danger">
                    Unable to filter timeline. Please refresh the page and try again.
                </div>
            `;
        }
    }
}

function initializeTimelineEvents() {
    // Initialize expand/collapse functionality
    document.querySelectorAll('.timeline_date_header').forEach(header => {
        header.addEventListener('click', () => toggleDateSection(header));
    });

    document.querySelectorAll('.model_header').forEach(header => {
        header.addEventListener('click', () => toggleModelGroup(header));
    });
}

/**
 * Clear selection (All button)
 */
async function clearSelection(allBtnEl) {
    // Remove hover effects from all buttons
    document.querySelectorAll('.model_filter_btn').forEach(btn => {
        btn.style.transform = 'translateY(0)';
    });

    // Update button states
    const wrapper = allBtnEl.closest(".filter_buttons_wrapper");
    if (wrapper) {
        wrapper.querySelectorAll(".model_filter_btn").forEach(btn =>
            btn.classList.remove("selected_btn"));
        allBtnEl.classList.add("selected_btn");
    }

    // Apply 'all' filter
    const container = document.getElementById('timeline_container');
    if (!container || !container.dataset.resId) return;

    try {
        const result = await fetch("/web/dataset/call_kw", {
            method: "POST",
            credentials: "same-origin",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                jsonrpc: "2.0",
                method: "call",
                params: {
                    model: getCurrentTimelineModel(),
                    method: "filter_timeline_data",
                    args: ['all'],
                    kwargs: {
                        context: { active_id: parseInt(container.dataset.resId) }
                    },
                },
            }),
        });

        const response = await result.json();
        if (response.result && response.result.html) {
            container.innerHTML = response.result.html;
        }
    } catch (err) {
        console.error("Timeline filtering failed:", err);
    }
}

/**
 * Apply model filters via RPC
 */
async function applyModelFilters(resId) {
    try {
        const values = selectedModelIds.length
            ? { selected_model_ids: [[6, 0, selectedModelIds.map(Number)]], active_model: null }
            : { selected_model_ids: [[5]], active_model: "all" };

        const currentModel = getCurrentTimelineModel();

        const resp = await fetch("/web/dataset/call_kw", {
            method: "POST",
            credentials: "same-origin",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                jsonrpc: "2.0",
                method: "call",
                params: {
                    model: currentModel,
                    method: "write",
                    args: [[resId], values],
                    kwargs: { context: {} },
                },
            }),
        });
        const result = await resp.json();
        if (!result.error) window.location.reload();
    } catch (err) {
        console.error("applyModelFilters error:", err);
    }
}

/**
 * Open timeline record using Odoo action service
 */
function openTimelineRecord(model, id) {
    const actionService = registry.category("services").get("action");
    if (!model || !id || !actionService) return;

    actionService.doAction({
        type: "ir.actions.act_window",
        res_model: model,
        res_id: id,
        views: [[false, "form"]],
        target: "current",
    });
}

/**
 * Toggle date sections
 */
 function toggleDateSection(element) {
    const container = element.nextElementSibling;
    const icon = element.querySelector('.toggle_icon');

    if (container.classList.contains('expanded')) {
        // Collapse whole date
        container.classList.remove('expanded');
        element.classList.add('collapsed');
        icon.innerHTML = '▼';
    } else {
        // Expand only model headers (collapsed by default)
        container.classList.add('expanded');
        element.classList.remove('collapsed');
        icon.innerHTML = '▲';

        // Ensure all model groups inside are collapsed initially
        container.querySelectorAll('.model_records').forEach(group => {
            group.classList.add('collapsed');  // hide records
        });
        container.querySelectorAll('.model_header .toggle_icon').forEach(icon => {
            icon.innerHTML = '▼'; // collapsed state
        });
    }
}

/**
 * Toggle model groups
 */
function toggleModelGroup(element) {
    const container = element.nextElementSibling;
    const icon = element.querySelector('.toggle_icon');

    if (container.classList.contains('expanded')) {
        // Expand model group
        container.classList.remove('expanded');
        element.classList.remove('collapsed');
        icon.innerHTML = '▼';
    } else {
        // Collapse model group
        container.classList.add('expanded');
        element.classList.add('collapsed');
        icon.innerHTML = '▲';
    }
}

/**
 * Toggle mobile "More" dropdown
 */
function toggleMobileMoreDropdown() {
    const content = document.getElementById('mobileDropdownContent');
    const toggle = document.querySelector('.mobile_more_btn');

    if (content && toggle) {
        content.classList.toggle('show');
        toggle.classList.toggle('active');
    }
}

/**
 * Initialize mobile filter events
 */
function initializeMobileFilters() {
    // Close mobile dropdown when clicking outside
    document.addEventListener('click', function(event) {
        const dropdown = document.querySelector('.mobile_more_dropdown');
        const content = document.getElementById('mobileDropdownContent');
        const toggle = document.querySelector('.mobile_more_btn');

        if (dropdown && !dropdown.contains(event.target) && content && content.classList.contains('show')) {
            content.classList.remove('show');
            if (toggle) toggle.classList.remove('active');
        }
    });

    // Handle window resize
    window.addEventListener('resize', function() {
        const content = document.getElementById('mobileDropdownContent');
        const toggle = document.querySelector('.mobile_more_btn');

        // Close mobile dropdown when switching to desktop
        if (window.innerWidth > 768 && content && content.classList.contains('show')) {
            content.classList.remove('show');
            if (toggle) toggle.classList.remove('active');
        }
    });
}

// Bind events after DOM loaded
document.addEventListener("DOMContentLoaded", () => {
    const container = document.getElementById('timeline_container');
    if (container && container.dataset.loaded === "1") {
        // Set initial active state for 'All' filter
        const allBtn = document.querySelector('.model_filter_btn');
        if (allBtn) {
            allBtn.classList.add('selected_btn');
            clearSelection(allBtn);
        }
    }

    initializeTimelineEvents();
});

// Export functions (removed loadTimeline since we're using server action now)
window.filterTimelineByModel = filterTimelineByModel;
window.clearSelection = clearSelection;
window.toggleDateSection = toggleDateSection;
window.toggleModelGroup = toggleModelGroup;
window.toggleMobileMoreDropdown = toggleMobileMoreDropdown;