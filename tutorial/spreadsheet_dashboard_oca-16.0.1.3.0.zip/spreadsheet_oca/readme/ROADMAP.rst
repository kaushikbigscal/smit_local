Adding new lines on pivot tables
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

When we add a pivot table, the number of rows is predefined according to the current data.

In order to add new rows, we need to reinsert the pivot table.
