* Holger Brunn <hbrunn@therp.nl>
* Ronald Portier <rportier@therp.nl>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Sergio Teruel
  * Carlos Dauden

* Iván Todorovich <ivan.todorovich@camptocamp.com>
* Carlos Serra-Toro <carlos.serra@braintec.com>
