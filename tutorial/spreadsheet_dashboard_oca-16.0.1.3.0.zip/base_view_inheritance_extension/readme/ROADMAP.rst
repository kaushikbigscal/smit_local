* Support an ``eval`` attribute for our new node types.
