To use this module, you need to:

1.  Go to Settings \> Users & Companies
2.  Define your territories, branches, districts and regions with their
    respective manager.
