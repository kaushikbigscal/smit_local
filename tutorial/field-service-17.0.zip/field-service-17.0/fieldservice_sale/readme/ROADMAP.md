- Provide a mapping between an address and the branch and use it to set
  the pricelist of a new partner
