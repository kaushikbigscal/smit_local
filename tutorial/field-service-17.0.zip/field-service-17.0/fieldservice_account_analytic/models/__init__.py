# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import (
    account_move,
    analytic_account,
    fsm_location,
    fsm_order,
    res_company,
    res_config_settings,
    res_partner,
)
