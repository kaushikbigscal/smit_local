The module integrates the field service application with CRM
opportunities. This can be useful in scenarios where onsite personnel
are needed for evaluation or surveying before quoting.
