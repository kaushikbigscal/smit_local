This modules creates calendar event from FSM Orders.
