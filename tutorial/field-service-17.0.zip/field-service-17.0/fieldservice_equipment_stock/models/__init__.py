from . import (
    stock_move,
    stock_picking_type,
    fsm_equipment,
    product_template,
    stock_lot,
)
