This module is an add-on for the Field Service application in Odoo. It
allows you to track your FSM Equipments in stock moves.
