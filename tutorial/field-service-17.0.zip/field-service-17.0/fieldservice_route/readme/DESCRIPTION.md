A Field Service route is the sorted list of orders that one
worker/vehicle will perform during a day.

This module allows you to manage your Field Service routes: when
assigning an order to a worker and scheduling it, a route is
automatically created for that worker and day.
