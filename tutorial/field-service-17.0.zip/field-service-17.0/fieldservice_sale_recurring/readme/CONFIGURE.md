To setup a product for quoting and selling field service orders:

- Go to Sales \> Catalog \> Products

- Create or select a product

- Set the Product Type to 'Service' under General Information tab

- Under Invoicing tab, set the Field Service Tracking option

- Select the FSM Order Template that will be used for creating FSM Orders when  
  a Sale Order is confirmed with this product
