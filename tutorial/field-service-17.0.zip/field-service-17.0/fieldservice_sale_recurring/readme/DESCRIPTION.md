This module allows you to sell recurring field services.
