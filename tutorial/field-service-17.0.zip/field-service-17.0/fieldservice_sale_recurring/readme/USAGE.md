- Go to Sales
- Create a new Quotation/Sale Order
- Set the FSM Location to be used
- On a Sale Order Line, select a product configured for field service
  orders
- Confirm the Sale Order
- Field Service Recurring Orders are generated and linked with sale order line
