To install Field Service and have the mapping features, you need to
install GeoEngine.

Please refer to the installation instructions available at:
<https://github.com/OCA/geospatial/tree/12.0/base_geoengine>
