- Open Source Integrators  
  - Wolfgang Hall \<<whall@opensourceintegrators.com>\>
  - Maxime Chambreuil \<<mchambreuil@opensourceintegrators.com>\>
  - Steve Campbell \<<scampbell@opensourceintegrators.com>\>
  - Bhavesh Odedra \<<bodedra@opensourceintegrators.com>\>
  - Michael Allen \<<mallen@opensourceintegrators.com>\>
  - Sandip Mangukiya \<<smangukiya@opensourceintegrators.com>\>
  - Jevin Dement \<<jdement@opensourceintegrators.com>\>

- Murtuza Saleh \<<murtuza.saleh@serpentcs.com>\>

- Sebastiano Picchi \<<sebastiano.picchi@pytech.it>\>

- \[APSL-Nagarro\](<https://apsl.tech>):
  - Antoni Marroig \<<amarroig@apsl.net>\>
