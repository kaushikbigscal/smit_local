A Field Service Activity gives the user the ability to define a list of
tasks/activities on a service order

The user can add tasks/activities to the FSM order to the ones created
from the template.
