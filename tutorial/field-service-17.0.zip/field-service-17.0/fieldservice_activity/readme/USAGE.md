To use this module, you need to:

- Go to Field Service
- Create or select an FSM Order
- Add as many Activites as needed
- Alternatively, add Activites to a Template
- Add Template to FSM Order, Activites will be copied over
