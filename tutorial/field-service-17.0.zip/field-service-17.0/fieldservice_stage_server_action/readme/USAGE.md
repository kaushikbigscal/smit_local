- Go to Field Service
- Select or create a FSM orders
- Move it to the stage configured before to trigger the execution of the
  server action
