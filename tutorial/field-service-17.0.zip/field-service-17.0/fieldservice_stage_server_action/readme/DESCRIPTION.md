This module allows you to execute server actions when a FSM orders
enters a specific stage.
