To use this module, you need to:

- Go to Field Service
- Create a FSM order
- Choose the type: Repair
- Select the equipment
- Upon saving, a repair order is created and linked to the FSM order
