To configure this module, you need to:

- Go to Field Service \> Master Data \> Equipments
- Set the product and serial number on each of your equipments
