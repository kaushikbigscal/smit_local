The stage of an order is used to monitor its progress. Stages can be
configured based on your company's specific business needs. A basic set
of order stages comes pre-configured for use.

1.  Go to *Field Service \> Configuration \> Stages*
2.  Create or edit a stage
3.  Set the name for the stage.
4.  Set the sequence order for the stage.
5.  Select *Order* type to apply this stage to your orders.
6.  Additonally, you can set a color for the stage.
