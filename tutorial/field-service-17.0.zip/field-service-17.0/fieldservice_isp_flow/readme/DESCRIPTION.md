This module is an add-on for the Field Service application in Odoo. It
provides default stages for orders and some validation logic when
changing current stage.
