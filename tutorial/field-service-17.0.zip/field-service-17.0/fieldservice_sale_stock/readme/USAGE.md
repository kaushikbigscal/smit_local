- Go to Sales
- Create a new Quotation/Sale Order
- Set the FSM Location to be used
- On a Sale Order Line, select a product configured for field service
  orders
- Confirm the Sale Order
- Field Service orders linked to SO lines are created
- The pickings for storable products will get linked to the newly
  created field service order
