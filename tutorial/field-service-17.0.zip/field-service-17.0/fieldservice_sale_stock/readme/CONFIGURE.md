Configure a storable product that generates a unique field service order
for an individual sale order:

- Go to Sales \> Catalog \> Products
- Create or select a product
- Set the type to 'Storable'
- Set the Service Policy to 'Per Sale Order'
