This module links pickings created by a sale order to the field service
order created by the sale order.
